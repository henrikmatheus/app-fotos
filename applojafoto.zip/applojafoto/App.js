import {NavigationContainer} from '@react-navigation/native';
import TabRotas from './components/TabRotas';

export default function App() {
  return(
    <NavigationContainer>
     <TabRotas/>
    </NavigationContainer>
  );
}
