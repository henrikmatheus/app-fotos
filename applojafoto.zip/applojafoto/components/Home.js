import { Text, SafeAreaView, StyleSheet,Image} from 'react-native';

export default function Acesso() {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.titulo}>
        Aplicativo de Fotos
      </Text>
      <Image source={require('../assets/camera-1130731_640.jpg')}/>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex:1,
    justifyContent:'center',
    backgroundColor:'#ecf0f1',
    padding:8,
  },
  titulo:{
    margin:24,
    fontSize:38,
    fontWeight:'bold',
    textAlign:'center'
  }
});
