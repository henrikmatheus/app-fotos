import { initializeApp } from "firebase";

const firebaseConfig = {
  apiKey: "AIzaSyBkdCFVrh2HZa2oQBPgzO8W-nkjaHqr16I",
  authDomain: "acessobdlojakkk.firebaseapp.com",
  projectId: "acessobdlojakkk",
  storageBucket: "acessobdlojakkk.appspot.com",
  messagingSenderId: "331995749807",
  appId: "1:331995749807:web:4c4528bde778c02a16a35a"
};
const app = initializeApp(firebaseConfig);
export default app;